import express from 'express';
import fs from 'fs';
import https from 'https';
import cors from 'cors';

import { createTableUsuarios } from './controllers/usuarios.js';
import { createTableProdutos } from './controllers/produtos.js';
import { createTableCarrinho } from './controllers/carrinho.js';

createTableUsuarios();
createTableProdutos();
createTableCarrinho();

const app = express();
app.use(express.json());
app.use(cors());

import router from './routes.js'
app.use(router);

// porta do express
// app.listen(3000, () => console.log("Api Rodando."));
const port = process.env.PORT | 3000;
app.listen(port, () => {
  console.log(`Api online na porta: http://localhost:${port}`);
});

https.createServer({
    cert: fs.readFileSync('src/SSL/code.crt'),
    key: fs.readFileSync('src/SSL/code.key'),
}, app).listen(3001,()=>console.log("Rodando em https!"));