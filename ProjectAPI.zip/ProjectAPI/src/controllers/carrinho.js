import {
    openDb
} from "../database/configDB.js";

export async function createTableCarrinho() {
    openDb().then(db => {
        db.exec('CREATE TABLE IF NOT EXISTS carrinho (id INTEGER PRIMARY KEY, usuario_id INTEGER,produto_id INTEGER,  status VARCHAR(100), FOREIGN KEY(usuario_id) REFERENCES Usuarios(id),FOREIGN KEY(produto_id) REFERENCES Produtos(id))')
    })
};

// mostrar carrinhos 
export async function selectCarrinhos(req, res) {
    openDb().then(db => {
        db.all('SELECT * FROM carrinho')
            .then(carrinhos => res.json(carrinhos))
    })
};
// mostrar carrinho especifico pelo id
export async function selectCarrinho(req, res) {
    let id = req.body.id;
    openDb().then(db => {
        db.get('SELECT * FROM carrinho WHERE id=?', [id])
            .then(carrinho => res.json(carrinho))
    })
};

// inserir/colocar carrinho
export async function insertCarrinho(req, res) {
    let carrinho = req.body;
    openDb().then(db => {
        db.run('INSERT INTO carrinho (usuario_id, produto_id, status) VALUES (?,?,?)', [carrinho.usuario_id, carrinho.produto_id, carrinho.status])
    })
    res.json({
        "statusCode": 200
    })
};

// atualizar carrinho
export async function updateCarrinho(req, res) {
    let carrinho = req.body;
    openDb().then(db => {
        db.run('UPDATE carrinho SET usuario_id=?, produto_id=?, status=? WHERE id=?', [carrinho.usuario_id, carrinho.produto_id, carrinho.status, carrinho.id])
    })
    res.json({
        "statusCode": 200
    })
};

// deletar carrinho
export async function deleteCarrinho(req, res) {
    let id = req.body.id;
    openDb().then(db => {
        db.get('DELETE FROM carrinho WHERE id=?', [id])
            .then(res => res)
    })
    res.json({
        "statusCode": 200
    })
};