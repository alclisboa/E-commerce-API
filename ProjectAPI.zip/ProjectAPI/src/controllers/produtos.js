import {
    openDb
} from "../database/configDB.js";

export async function createTableProdutos() {
    openDb().then(db => {
        db.exec('CREATE TABLE IF NOT EXISTS produtos (id INTEGER PRIMARY KEY, titulo VARCHAR, descricao VARCHAR, valor FLOAT)')
    })
}

// mostrar produtos
export async function selectProdutos(req, res) {
    openDb().then(db => {
        db.all('SELECT * FROM produtos')
            .then(produtos => res.json(produtos))
    });
}
// mostrar produto especifico por id
export async function selectProduto(req, res) {
    let id = req.body.id;
    openDb().then(db => {
        db.get('SELECT * FROM produtos WHERE id=?', [id])
            .then(produto => res.json(produto))
    });
}

// inserir produtos
export async function insertProdutos(req, res) {
    let produtos = req.body;
    openDb().then(db => {
        db.run('INSERT INTO produtos (titulo, descricao, valor) VALUES(?,?,?)', [produtos.titulo, produtos.descricao, produtos.valor]);
    })
    res.json({
        "statusCode": 200
    })
}

// atualizar produtos
export async function updateProdutos(req, res) {
    let produtos = req.body;
    openDb().then(db => {
        db.run('UPDATE produtos SET titulo=?, descricao=?, valor=? WHERE id=?', [produtos.titulo, produtos.descricao, produtos.valor, produtos.id]);
    })
    res.json({
        "statusCode": 200
    })
}

// deletar produtos
export async function deleteProduto(req, res) {
    let id = req.body.id;
    openDb().then(db => {
        db.get('DELETE FROM produtos WHERE id=?', [id])
            .then(res => res)
    })
    res.json({
        "statusCode": 200
    })
}