import {
    openDb
} from "../database/configDB.js";

export async function createTableUsuarios() {
    openDb().then(db => {
        db.exec('CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nome VARCHAR, email VARCHAR, senha VARCHAR)')
    })
}

// mostrar usuarios
export async function selectUsuarios(req, res) {
    openDb().then(db => {
        db.all('SELECT * FROM usuarios')
            .then(usuarios => res.json(usuarios))
    });
}
// mostrar usuario pelo id
export async function selectUsuario(req, res) {
    let id = req.body.id;
    openDb().then(db => {
        db.get('SELECT * FROM usuarios WHERE id=?', [id])
            .then(usuario => res.json(usuario))
    });
}

// inserir usuarios
export async function insertUsuarios(req, res) {
    let usuarios = req.body;
    openDb().then(db => {
        db.run('INSERT INTO usuarios (nome, email, senha) VALUES(?,?,?)', [usuarios.nome, usuarios.email, usuarios.senha]);
    })
    res.json({
        "statusCode": 200
    })
}

// atualizar usuarios
export async function updateUsuarios(req, res) {
    let usuarios = req.body;
    openDb().then(db => {
        db.run('UPDATE usuarios SET nome=?, email=?, senha=? WHERE id=?', [usuarios.nome, usuarios.email, usuarios.senha, usuarios.id]);
    })
    res.json({
        "statusCode": 200
    })
}

// deletar usuario
export async function deleteUsuario(req, res) {
    let id = req.body.id;
    openDb().then(db => {
        db.get('DELETE FROM usuarios WHERE id=?', [id])
            .then(res => res)
    })
    res.json({
        "statusCode": 200
    })
}