import {
    Router
} from "express";

import {
    createTableUsuarios,
    insertUsuarios,
    updateUsuarios,
    selectUsuario,
    selectUsuarios,
    deleteUsuario
} from './controllers/usuarios.js';

import {
    createTableProdutos,
    insertProdutos,
    updateProdutos,
    selectProdutos,
    selectProduto,
    deleteProduto
} from './controllers/produtos.js';

import {
    createTableCarrinho,
    selectCarrinhos,
    selectCarrinho,
    insertCarrinho,
    updateCarrinho,
    deleteCarrinho
} from "./controllers/carrinho.js";

const router = Router();

// teste visual da api
router.get('/', (req, res) => {
    res.json({
        "statusCode": 200,
        "msg": "API FUNCIONANDO!"
    })
})


//🛍️🛍️🛍️🛍️🛍️ | PRODUTOS | 🛍️🛍️🛍️🛍️🛍️

// mostra produto e produtos pelo id
router.get('/produto', selectProduto);
router.get('/produtos', selectProdutos);
// insere/cadastra novos produtos
router.post('/produtos', insertProdutos);
// atuliza os produtos
router.put('/produtos', updateProdutos);
// deleta os produtos
router.delete('/produto', deleteProduto);


//👩🏽‍💻👩🏽‍🦳👩🏽‍🦰👨🏽‍🦰👧🏽 | USUARIOS | 👩🏽‍💻👩🏽‍🦳👩🏽‍🦰👨🏽‍🦰👧🏽

// mostra usuarios e usuarios pelo id
router.get('/usuario', selectUsuario);
router.get('/usuarios', selectUsuarios);
// insere/cadastra novos usuarios
router.post('/usuarios', insertUsuarios);
// atuliza os usuarios
router.put('/usuarios', updateUsuarios);
// deleta os ususarios
router.delete('/usuario', deleteUsuario);

// 🛒🛒🛒🛒🛒 | CARRINHO | 🛒🛒🛒🛒🛒

// mostra carrinhos e carrinho pelo id
router.get('/carrinho', selectCarrinho);
router.get('/carrinhos', selectCarrinhos);
// insere/cadastra novos carrinhos
router.post('/carrinhos', insertCarrinho);
// atuliza os carrinhos
router.put('/carrinhos', updateCarrinho);

// deleta os carrinhos
router.delete('/carrinhos', deleteCarrinho);

export default router;